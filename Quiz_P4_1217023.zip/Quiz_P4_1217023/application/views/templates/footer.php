</br>
<footer>
    <strong> &copy; Copyright </strong>  
    <span><strong>Quiz P4 Yusuf 1217023</strong></span>
</footer>