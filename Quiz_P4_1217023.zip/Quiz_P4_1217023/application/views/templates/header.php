<link rel="stylesheet" href="<?php echo base_url();?>assets/css/Button.css">
<head>
	<body>
		<h1>Pengelolaan Data CRUD</h1>
	<p>
		<a class="buttonhijau" href="<?php echo site_url();?>">Home</a>
	</p>
</body>
</head>