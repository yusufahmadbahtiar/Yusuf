<link rel="stylesheet" href="<?php echo base_url();?>assets/css/Table.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/Button.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/Style.css">
<h2><?php echo $title; ?></h2>
<table cellspacing='0'>
		<thead>
			<tr>
				<th>NIM</th>
				<th>Nama</th>
				<th>Judul</th>
				<th>Pembimbing</th>
				<th>Aksi</th>
			</tr>
		</thead>
	<?php foreach ($tskripsi as $skripsi_item): ?> 
	<tr>            
	 	<th><?php echo $skripsi_item['nim']; ?></th>             
	 	<th><?php echo $skripsi_item['nama']; ?></th>
	 	<th><?php echo $skripsi_item['judul']; ?></th>
	 	<th><?php echo $skripsi_item['pemb']; ?></th>             
	 	<th><button class="buttonkuning"><a class="buttonkuning" href="<?php echo site_url('skripsi/edit/'.$skripsi_item['nim']); ?>">Edit</a></button> |                  
	 		<button class="buttonmerah"><a class="buttonmerah" href="<?php echo site_url('skripsi/delete/'.$skripsi_item['nim']); ?>" onClick="return confirm('Are you sure you want to delete?')">Delete</a></button>             
	 	</td>         
	 </tr> 
	<?php endforeach; ?> 
</table> 
 