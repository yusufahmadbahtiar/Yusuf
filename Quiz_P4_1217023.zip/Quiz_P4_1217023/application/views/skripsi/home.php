<html>
<head>
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/Table.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/Style.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/Button.css">
	<body>
		<h1><strong><center>Pengelolaan Data CRUD</center></strong></h1>
	<div align="center">
		<tr>
			<td>
				<button class="buttonhijau"><a href="<?php echo site_url('skripsi/insert_data');?>" class="buttonhijau">Insert Data</a></button>
			</td>
		</tr>
	</div>
	<div align="center">
		<tr>
			<td>
				<button class="buttonkuning"><a href="<?php echo site_url('skripsi/tampil');?>" class="buttonkuning">Tampil Data</a>
				</button>
			</td>
		</tr>
	</div>
</body>
</head>
</html>