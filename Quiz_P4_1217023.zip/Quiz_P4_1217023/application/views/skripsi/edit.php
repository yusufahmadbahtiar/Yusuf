<link rel="stylesheet" href="<?php echo base_url();?>assets/css/Style.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/Table.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/Button.css">
<h2><?php echo $title; ?></h2>   
<?php echo validation_errors(); ?>   
<?php echo form_open('skripsi/edit/'.$skripsi_item['nim']); ?>

<form>
<ul class="form-style-1">
    <li>
        <label for="nim">NIM<span class="required">*</span></label>
        <input type="input" name="nim" class="field" value="<?php echo $skripsi_item['nim'] ?>" />
    </li>
    <li>
        <label for="nama">Nama<span class="required">*</span></label>
        <input type="input" name="nama" class="field" value="<?php echo $skripsi_item['nama'] ?>"  />
    </li>
    <li>
        <label for="judul">Judul<span class="required">*</span></label>
        <input type="input" name="judul" class="field" value="<?php echo $skripsi_item['judul'] ?>" />
    </li>
    <li>
        <label for="nim">Pembimbing<span class="required">*</span></label>
        <input type="input" name="pemb" class="field" value="<?php echo $skripsi_item['pemb'] ?>" />
    </li>
    <li>
        <input type="submit" value="Edit Data" />
    </li>
</ul>
</form>     
