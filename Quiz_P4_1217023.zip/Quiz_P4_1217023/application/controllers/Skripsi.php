<?php 

class Skripsi extends CI_Controller 
{       
	public function __construct()     
	{         
		parent::__construct();         
		$this->load->model('skripsi_model');         
		$this->load->helper('url_helper');     
	}  

	public function index()
	{
		$this->load->view('skripsi/home');  
	}     

	public function tampil()     
	{         
		$data['tskripsi'] = $this->skripsi_model->get_skripsi();         
		$data['title'] = 'Tampil Data';           
		$this->load->view('templates/header', $data);         
		$this->load->view('skripsi/tampil_data', $data);         
		$this->load->view('templates/footer');     
	}       
	
	public function insert_data()     
	{         
		$this->load->helper('form');         
		$this->load->library('form_validation');  

		$data['title'] = 'Buat Data Baru'; 

		$this->form_validation->set_rules('nim', 'NIM', 'required');         
		$this->form_validation->set_rules('nama', 'Nama', 'required');
		$this->form_validation->set_rules('judul', 'Judul', 'required');  
		$this->form_validation->set_rules('pemb', 'Pembimbing', 'required');  

		if ($this->form_validation->run() == FALSE)         
		{             
			$this->load->view('templates/header', $data);             
			$this->load->view('skripsi/insert_data');             
			$this->load->view('templates/footer');           
		}         
		else         
		{             
			$this->skripsi_model->set_skripsi();             
			$this->load->view('templates/header', $data);             
			$this->load->view('skripsi/success');             
			$this->load->view('templates/footer');         }     
		}          

		public function edit()     
		{         
			$nim = $this->uri->segment(3);                  
			
			if (empty($nim))         
				{             
					show_404();         
				}

			$this->load->helper('form');         
			$this->load->library('form_validation');

				$data['title'] = 'Edit Data Skripi';                 
				$data['skripsi_item'] = $this->skripsi_model->get_skripsi_by_nim($nim);

			$this->form_validation->set_rules('nim', 'NIM', 'required');         
			$this->form_validation->set_rules('nama', 'Nama', 'required');
			$this->form_validation->set_rules('judul', 'Judul', 'required');  
			$this->form_validation->set_rules('pemb', 'Pembimbing', 'required');  


			if ($this->form_validation->run() == FALSE)         
			{             
				$this->load->view('templates/header', $data);             
				$this->load->view('skripsi/edit', $data);             
				$this->load->view('templates/footer');           
			}        
			else         
			{             
				$this->skripsi_model->set_skripsi($nim);             
		            
				redirect( base_url() . 'index.php/skripsi');         
			}     
		}          

		public function delete()     
		{         
			$nim = $this->uri->segment(3);                  
			
			if (empty($nim))         
				{             
					show_404();         
				}

			$skripsi_item = $this->skripsi_model->get_skripsi_by_nim($nim);                  
			$this->skripsi_model->delete_skripsi($nim);                 
			redirect( base_url() . 'index.php/skripsi');             
		} 
	} 