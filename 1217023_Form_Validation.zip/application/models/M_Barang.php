<?php
/**
 * 
 */
class M_Barang extends CI_Model
{
	public $kode;
	public $nama;
	public $harga;
	public $stok;

	public $labels = [];
	
	function __construct()
	{
		$this->labels = $this->attributelabels();
		//memulai library database
		$this->load->database();
	}

	//metode untuk menambah baris data ke dalam tabel
	public function insert()
	{
		$sql = sprintf("INSERT INTO barang VALUES('%s','%s',%f,%d)",
			$this->kode,
			$this->nama,
			$this->harga,
			$this->stok
		);
		$this->db->query($sql);
	}
	private function attributelabels()
	{
		return
		[
			'kode'=>'Kode : ',
			'nama'=>'Nama Produk : ',
			'harga'=>'Harga Produk: ',
			'stok'=>'Stok : '
		];
	}
}
