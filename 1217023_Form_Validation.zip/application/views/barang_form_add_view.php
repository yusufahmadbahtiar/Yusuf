<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>1217023 Form Validation</title>
    <!-- Bootstrap -->
    <link href="<?php echo base_url();?>bootstrap/css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>
  <div class="container">
  	<?php if (validation_errors()) : ?>
      <div class="alert alert-danger">
        <?php echo validation_errors(); ?>
      </div>
  	<?php endif; ?>

    <div class="row">
      <div class="col-md-4"></div>
       <div class="col-md-4">
          <h1>Form Tambah Barang</h1>
			<?php echo form_open('Barang'); ?>
         <div class="row">
           <div class="form-group">
           	<?php echo $model->labels['kode'];?>
            <input type="text" placeholder="Kode" class="form-control" name="kode" id="kd">
          </div>
          <div class="form-group">
          	<?php echo $model->labels['nama'];?>
            <input type="text" placeholder="Nama" class="form-control" name="nama" id="nm">
          </div>
           <div class="form-group">
           	<?php echo $model->labels['harga'];?>
            <input type="text" placeholder="Harga" class="form-control" name="harga" id="hrg">
          </div>
          <div class="form-group">
          	<?php echo $model->labels['stok'];?>
            <input type="number" placeholder="Stok" class="form-control" name="stok" id="stk">
          </div>
          <div class="form-group">
            <input type="submit" name="btnSubmit"  class="btn btn-success" value="Tambah"/>
            <input type="reset" name="btnReset"  class="btn btn-primary" value="Reset" />
          </div>
          </form>
      </div>
       <div class="col-md-4"></div>
    </div>
  </div>
  <footer>
    <center><strong> &copy; Copyright Yusuf Ahmad Bahtiar</strong></center>
  </footer>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo base_url() ?>bootstrap/css/bootstrap.min.css/js/bootstrap.min.js"></script>
  </body>
</html> 