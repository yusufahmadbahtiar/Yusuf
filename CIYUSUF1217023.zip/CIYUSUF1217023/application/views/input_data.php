<html>
<head>
	
</head>
<body>
	<form method="POST" action="http://localhost/CIYUSUF1217023/index.php/welcome/luass3">
		ALAS: <input type="text" name="nalas"><br>
		TINGGI: <input type="text" name="ntinggi"><br>
		<input type="SUBMIT" name="submit" text="Hitung">
	</form>
</body>
