<?php
/**
 * 
 */
class Barang extends CI_Controller
{
	public $model = NULL;

	public function __construct()
	{
		parent::__construct();
		
		//memuat model
		$this->load->model('M_Barang');
		$this->model = $this->M_Barang;
	}

	public function index()
	{
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');

        $this->form_validation->set_rules('kode','Kode','required');
        $this->form_validation->set_rules('nama','Nama','required');
        $this->form_validation->set_rules('harga','Harga','required'); 
        $this->form_validation->set_rules('stok','Stok','required'); 

        if ($this->form_validation->run() == FALSE)
        {
            $this->load->view('barang_form_add_view',['model'=> $this->model]);
        }
        else
        {
        	if(isset ($_POST['btnSubmit']))
		  	{
            	$this->model->kode = $_POST['kode'];
		    	$this->model->nama = $_POST['nama'];
		    	$this->model->harga = $_POST['harga'];
				$this->model->stok = $_POST['stok'];

				//memanggil metode insert
				$this->model->insert();
				$this->load->view('barang_respon_add_view',['model'=> $this->model]);
        	}
        	else
        	{
				$this->load->view('barang_form_add_view',['model'=> $this->model]);
        	}
       }
	}
}