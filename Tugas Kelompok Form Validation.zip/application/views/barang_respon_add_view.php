<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tugas Kelompok</title>
    <!-- Bootstrap -->
    <link href="<?php echo base_url() ?>bootstrap/css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>
  <div class="container">
  	<div class="alert alert-success">
        <center><?php echo ('Data yang anda masukan berhasil'); ?></center>
  </div>
    <div class="row">
      <div class="col-md-4"></div>
       <div class="col-md-4">
          <h1>Hasil Data Inputan</h1>
        <form>
         <div class="row">
           <div class="form-group">
           	<?php echo $model->labels['kode'];?>
            <input type="text" placeholder="Kode Produk" class="form-control" value="<?php echo $model->kode;?>" readonly>
          </div>
          <div class="form-group">
          	<?php echo $model->labels['nama'];?>
            <input type="text" placeholder="Nama Produk" class="form-control" value="<?php echo $model->nama;?>" readonly>
          </div>
           <div class="form-group">
           	<?php echo $model->labels['harga'];?>
            <input type="text" placeholder="Harga Produk" class="form-control" value="<?php echo $model->harga;?>" readonly>
          </div>
          <div class="form-group">
          	<?php echo $model->labels['stok'];?>
            <input type="text"  placeholder="Stok Produk" class="form-control" value="<?php echo $model->stok;?>" readonly>
          </div>
          <div class="form-group">
            <a href="<?php echo base_url();?>"><button class="btn btn-primary">Kembali</button>
          </div>
      </div>
       <div class="col-md-4"></div>
    </div>
  </div>
</div>
    
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo base_url() ?>bootstrap/css/bootstrap.min.css/js/bootstrap.min.js"></script>
  </body>
</html> 